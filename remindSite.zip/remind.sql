-- MySQL dump 10.13  Distrib 5.7.26, for Linux (x86_64)
--
-- Host: localhost    Database: remind
-- ------------------------------------------------------
-- Server version	5.7.26-0ubuntu0.16.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `Administradores`
--

DROP TABLE IF EXISTS `Administradores`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Administradores` (
  `cpf` varchar(30) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Administradores`
--

LOCK TABLES `Administradores` WRITE;
/*!40000 ALTER TABLE `Administradores` DISABLE KEYS */;
/*!40000 ALTER TABLE `Administradores` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Devs`
--

DROP TABLE IF EXISTS `Devs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Devs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nick` varchar(300) COLLATE utf8_unicode_ci NOT NULL,
  `apiKey` varchar(5000) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Devs`
--

LOCK TABLES `Devs` WRITE;
/*!40000 ALTER TABLE `Devs` DISABLE KEYS */;
INSERT INTO `Devs` VALUES (1,'manogray','A72BCAA68639C0760076536483E1BB67E00B02DA17651CCBD30B04580B994514');
/*!40000 ALTER TABLE `Devs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Disciplinas`
--

DROP TABLE IF EXISTS `Disciplinas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Disciplinas` (
  `codigo` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `idProfessor` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `nome` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `periodo` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`codigo`),
  KEY `fk_prof` (`idProfessor`),
  CONSTRAINT `fk_prof` FOREIGN KEY (`idProfessor`) REFERENCES `Professores` (`cpf`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Disciplinas`
--

LOCK TABLES `Disciplinas` WRITE;
/*!40000 ALTER TABLE `Disciplinas` DISABLE KEYS */;
INSERT INTO `Disciplinas` VALUES ('ICE015','567','Psicodiagnostico','2019/1'),('ICE025','567','AED2','2019/1'),('PSI001','567','Estagio 1','2019/1');
/*!40000 ALTER TABLE `Disciplinas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Matriculas`
--

DROP TABLE IF EXISTS `Matriculas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Matriculas` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idTerapeuta` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `idDisciplina` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `situacao` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_aluno` (`idTerapeuta`),
  KEY `fk_disciplina` (`idDisciplina`),
  CONSTRAINT `fk_aluno` FOREIGN KEY (`idTerapeuta`) REFERENCES `Terapeutas` (`cpf`),
  CONSTRAINT `fk_disciplina` FOREIGN KEY (`idDisciplina`) REFERENCES `Disciplinas` (`codigo`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Matriculas`
--

LOCK TABLES `Matriculas` WRITE;
/*!40000 ALTER TABLE `Matriculas` DISABLE KEYS */;
INSERT INTO `Matriculas` VALUES (12,'06264134511','PSI001','Aprovado');
/*!40000 ALTER TABLE `Matriculas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Notificacoes`
--

DROP TABLE IF EXISTS `Notificacoes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Notificacoes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tipo` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `emissor` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `receptor` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `dia` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `horario` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `horaData` datetime NOT NULL,
  `mensagem` varchar(5000) COLLATE utf8_unicode_ci DEFAULT NULL,
  `estado` varchar(300) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Notificacoes`
--

LOCK TABLES `Notificacoes` WRITE;
/*!40000 ALTER TABLE `Notificacoes` DISABLE KEYS */;
INSERT INTO `Notificacoes` VALUES (1,'Agendar','021','011','Segunda','14:00','2019-06-09 19:06:25',NULL,'Respondido'),(2,'Agendar','021','005','Segunda','16:00','2019-06-09 19:06:02',NULL,'Pendente'),(4,'Mensagem','021','011',NULL,NULL,'2019-06-10 04:06:02','Seu tratamento foi confirmado pelo terapeuta. SeráSegunda ás 14:00:00.','Respondido'),(5,'Agendar','987','12345','Segunda','15:00','2019-06-10 11:06:02',NULL,'Respondido'),(6,'Mensagem','001','12345',NULL,NULL,'2019-06-10 11:06:45','Seu tratamento foi confirmado pelo terapeuta. Será Segunda ás 15:00:00.','Respondido'),(7,'Agendar','06264134511','76257551269','Segunda','14:00','2019-06-23 18:06:50',NULL,'Respondido'),(8,'Mensagem','001','76257551269',NULL,NULL,'2019-06-23 18:06:18','Seu tratamento foi confirmado pelo terapeuta. Será Segunda ás 14:00:00.','Respondido');
/*!40000 ALTER TABLE `Notificacoes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Pacientes`
--

DROP TABLE IF EXISTS `Pacientes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Pacientes` (
  `cpf` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `endereco` varchar(500) COLLATE utf8_unicode_ci DEFAULT NULL,
  `disponibilidade` json DEFAULT NULL,
  `sexo` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `nascimento` date NOT NULL,
  `vinculoResidencial` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `fezTerapia` tinyint(1) NOT NULL,
  `localTerapia` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `demanda` longtext COLLATE utf8_unicode_ci NOT NULL,
  `gravidade` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `prioridade` int(11) DEFAULT '0',
  `estado` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  KEY `fk_user` (`cpf`),
  CONSTRAINT `fk_user` FOREIGN KEY (`cpf`) REFERENCES `Usuarios` (`cpf`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Pacientes`
--

LOCK TABLES `Pacientes` WRITE;
/*!40000 ALTER TABLE `Pacientes` DISABLE KEYS */;
INSERT INTO `Pacientes` VALUES ('123','CIDADE NOVA','[\"disponibilidade\"]','MASCULINO','1010-10-10','MAMÃƒE',0,'','PORQUE MAMÃƒE MANDOU','Grave',0,'Disponível'),('234','SÃƒO JORGE','[\"disponibilidade\"]','MASCULINO','1111-11-11','PAPAI',1,'','PORQUE EU QUIS','Grave',0,'Disponível'),('76257551269','Inferno','{\"Qua\": {\"fim\": \"\", \"inicio\": \"\"}, \"Qui\": {\"fim\": \"\", \"inicio\": \"\"}, \"Seg\": {\"fim\": \"18:00\", \"inicio\": \"08:00\"}, \"Sex\": {\"fim\": \"16:00\", \"inicio\": \"14:00\"}, \"Ter\": {\"fim\": \"\", \"inicio\": \"\"}}','MASCULINO','2000-12-21','Com meus pais',1,'Instituto Pense bem - Salvador','Todo mundo me odeia. E eu não sei como eu sinto com isso, só sei que sinto vontade de matar pessoas. Me faz sentir bem','Grave',0,'Em contato'),('015','Parque 10','{\"Qua\": {\"fim\": \"\", \"inicio\": \"\"}, \"Qui\": {\"fim\": \"\", \"inicio\": \"\"}, \"Seg\": {\"fim\": \"18:00\", \"inicio\": \"08:00\"}, \"Sex\": {\"fim\": \"10:00\", \"inicio\": \"08:00\"}, \"Ter\": {\"fim\": \"\", \"inicio\": \"\"}}','FEMININO','1970-10-10','Sozinha',1,'Clinica Psichosocial','Não consigo dormir. Vejo demônios','Grave',0,'Disponível'),('005','lugar','{\"Qua\": {\"fim\": \"18:00\", \"inicio\": \"08:01\"}, \"Qui\": {\"fim\": \"18:00\", \"inicio\": \"08:00\"}, \"Seg\": {\"fim\": \"18:00\", \"inicio\": \"08:00\"}, \"Sex\": {\"fim\": \"18:00\", \"inicio\": \"08:00\"}, \"Ter\": {\"fim\": \"18:00\", \"inicio\": \"08:00\"}}','MASCULINO','1970-10-09','asdasfda',1,'naofiz','asdasfasf','Grave',0,'Disponível'),('01553215281','Inferno','{\"Qua\": {\"fim\": \"\", \"inicio\": \"\"}, \"Qui\": {\"fim\": \"\", \"inicio\": \"\"}, \"Sab\": {\"fim\": \"16:00\", \"inicio\": \"08:00\"}, \"Seg\": {\"fim\": \"\", \"inicio\": \"\"}, \"Sex\": {\"fim\": \"\", \"inicio\": \"\"}, \"Ter\": {\"fim\": \"\", \"inicio\": \"\"}}','OUTRO','1999-10-10','asdasd',0,'','asdasdasdasd','Não Avaliado',0,'Disponível'),('06662812',NULL,NULL,'MASCULINO','1995-10-10','Sozinho',0,NULL,'POrra','Não Avaliado',0,'Disponível'),('555',NULL,'\"nothing\"','MASCULINO','1995-12-10','Sozinho',0,NULL,'Pq Sim','Não Avaliado',0,'Disponível'),('777',NULL,'\"nothing\"','MASCULINO','2019-07-09','sozinho',0,NULL,'ppra','Não Avaliado',0,'Disponível');
/*!40000 ALTER TABLE `Pacientes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Professores`
--

DROP TABLE IF EXISTS `Professores`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Professores` (
  `cpf` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  KEY `fk_user3` (`cpf`),
  CONSTRAINT `fk_user3` FOREIGN KEY (`cpf`) REFERENCES `Usuarios` (`cpf`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Professores`
--

LOCK TABLES `Professores` WRITE;
/*!40000 ALTER TABLE `Professores` DISABLE KEYS */;
INSERT INTO `Professores` VALUES ('567');
/*!40000 ALTER TABLE `Professores` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PsicologosRT`
--

DROP TABLE IF EXISTS `PsicologosRT`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `PsicologosRT` (
  `cpf` varchar(30) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PsicologosRT`
--

LOCK TABLES `PsicologosRT` WRITE;
/*!40000 ALTER TABLE `PsicologosRT` DISABLE KEYS */;
/*!40000 ALTER TABLE `PsicologosRT` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Sessoes`
--

DROP TABLE IF EXISTS `Sessoes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Sessoes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `descricao` longtext COLLATE utf8_unicode_ci NOT NULL,
  `horaData` datetime NOT NULL,
  `idTerapia` int(11) NOT NULL,
  `categoria` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_terapia` (`idTerapia`),
  CONSTRAINT `fk_terapia` FOREIGN KEY (`idTerapia`) REFERENCES `Terapias` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Sessoes`
--

LOCK TABLES `Sessoes` WRITE;
/*!40000 ALTER TABLE `Sessoes` DISABLE KEYS */;
INSERT INTO `Sessoes` VALUES (4,'Paciente teve um progresso significativo em relação a última sessão. Foi mais aberto e mais expressivo. Estava estranhamente contente mas com aparência ótima.','2019-06-24 23:06:26',5,'Regular'),(5,'Avisou com antecedência por telefone que teria um compromisso','2019-06-24 23:06:15',5,'Falta notificada');
/*!40000 ALTER TABLE `Sessoes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Terapeutas`
--

DROP TABLE IF EXISTS `Terapeutas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Terapeutas` (
  `cpf` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `disponibilidade` json NOT NULL,
  `crp` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL,
  `registroMatricula` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL,
  `situacao` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  KEY `fk_user2` (`cpf`),
  CONSTRAINT `fk_user2` FOREIGN KEY (`cpf`) REFERENCES `Usuarios` (`cpf`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Terapeutas`
--

LOCK TABLES `Terapeutas` WRITE;
/*!40000 ALTER TABLE `Terapeutas` DISABLE KEYS */;
INSERT INTO `Terapeutas` VALUES ('06264134511','{\"Qua\": {\"fim\": \"12:00\", \"inicio\": \"08:00\"}, \"Qui\": {\"fim\": \"12:00\", \"inicio\": \"08:00\"}, \"Seg\": {\"fim\": \"\", \"inicio\": \"\"}, \"Sex\": {\"fim\": \"16:00\", \"inicio\": \"14:00\"}, \"Ter\": {\"fim\": \"18:00\", \"inicio\": \"08:00\"}}',NULL,'345345',NULL),('02111873217','[\"disponibilidade\"]','456456',NULL,'Não Aprovado'),('021','{\"Qua\": {\"fim\": \"12:00\", \"inicio\": \"08:00\"}, \"Qui\": {\"fim\": \"12:00\", \"inicio\": \"08:00\"}, \"Seg\": {\"fim\": \"\", \"inicio\": \"\"}, \"Sex\": {\"fim\": \"16:00\", \"inicio\": \"14:00\"}, \"Ter\": {\"fim\": \"18:00\", \"inicio\": \"08:00\"}}',NULL,'21754006',NULL),('987','{\"Qua\": {\"fim\": \"23:00\", \"inicio\": \"22:00\"}, \"Qui\": {\"fim\": \"\", \"inicio\": \"\"}, \"Seg\": {\"fim\": \"11:00\", \"inicio\": \"09:00\"}, \"Sex\": {\"fim\": \"\", \"inicio\": \"\"}, \"Ter\": {\"fim\": \"00:00\", \"inicio\": \"23:00\"}}','21754006',NULL,'Não Aprovado'),('001','[\"disponibilidade\"]',NULL,NULL,NULL);
/*!40000 ALTER TABLE `Terapeutas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Terapias`
--

DROP TABLE IF EXISTS `Terapias`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Terapias` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idTerapeuta` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `idPaciente` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `estado` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `sala` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `dia` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `hora` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_tera` (`idTerapeuta`),
  KEY `fk_paciente` (`idPaciente`),
  CONSTRAINT `fk_paciente` FOREIGN KEY (`idPaciente`) REFERENCES `Pacientes` (`cpf`),
  CONSTRAINT `fk_tera` FOREIGN KEY (`idTerapeuta`) REFERENCES `Terapeutas` (`cpf`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Terapias`
--

LOCK TABLES `Terapias` WRITE;
/*!40000 ALTER TABLE `Terapias` DISABLE KEYS */;
INSERT INTO `Terapias` VALUES (5,'06264134511','76257551269','Em tratamento','2','Segunda','14:00:00');
/*!40000 ALTER TABLE `Terapias` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Usuarios`
--

DROP TABLE IF EXISTS `Usuarios`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Usuarios` (
  `cpf` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `nome` varchar(300) COLLATE utf8_unicode_ci NOT NULL,
  `senha` varchar(300) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email` varchar(500) COLLATE utf8_unicode_ci NOT NULL,
  `telefone` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`cpf`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Usuarios`
--

LOCK TABLES `Usuarios` WRITE;
/*!40000 ALTER TABLE `Usuarios` DISABLE KEYS */;
INSERT INTO `Usuarios` VALUES ('001','Remind',NULL,'remind@gmail.com',NULL),('005','alguem','$2y$10$JDKQzzY3JZxmOfO57WQTPOqk23adUE02VbB.v6OF82hNLSlYX1QWi','nothing@nothing.com','9999999999'),('015','Leda Brasil','$2y$10$nrAgYt6G4RU45Fop0ad.luRcaXksQLICcJ4yiyRixIUewM/1/GRoq','ledabrasil@brasil.com','9294006045'),('01553215281','Fodase','$2y$10$9mDun0Wrr7rrMReCkr27V.e019Y2Bh8j4L1N9l5.bQNjFNIdIygrC','jonathas.kerber@gma.com','9294006045'),('021','Ana Carla Vieira','$2y$10$zhGngi2xg0OaEOXn0YIUwOSYwnGkvmqxSsOOP1huHFjtDulxsp3fS','carlasouza1401@gmail.com','9294006045'),('02111873217','Jonathas Kerber','$2y$10$vatt0ON68bizMZs1QYKW0uk1tuVTVXenevBSD4VmT4p0PSUHwRrcK','jonathas@kerber.com','44444-4455'),('06264134511','Luiz Gonzaga','$2y$10$jw3B6px.pi0q6gq0m2jbG./VGPR/B30NEfWcRqWvQQ0NnlULJ3PVW','luiz@gonzaga.com','33333-3333'),('06662812','John','$2y$10$vW0Ob64RMZU.NB8DzroJzOW8WpSjQ50c5hbndtC3UAQBCjnXJ/nJi','mail@mail.com',NULL),('123','Evaldo Patrik','$2y$10$ExpflCqsjCoI.me7t/O1cetXb8y0maVU46Vzzuax69wvHWeWq3fDu','evaldo@patrik.com','11111-1111'),('12345','Jonathas Kerber','$2y$10$rmuFSuCjX4.rwk9GSC7ZW.ZKo5XXcNWM/wAPEJkN1iiLz4UwTQ/B.','jonathas.kerber@gma.com','321654987'),('234','Nader Naucher','$2y$10$3foiVmQMC2zm7l8/lf.FeenKRUfqK9bJivsTwkeq5tCj7pHRyFR06','nader@naucher.com','22222-2222'),('555','John','$2y$10$RiWK1Pwyw0.dz6CwAxFKS.sXhNWYE3bZMitZxvaULfW5iy7GGIvke','joul@joul.com',NULL),('567','Edson Filho','$2y$10$8m4DZd820z4uim7oUq.f7ODubgKoJCjx8ELEEZ/vq0HOCOExcGpmG','evaldo@patrik.com','55555-5555'),('76257551269','Renato Mota','$2y$10$OVHB4oix.6r9K3y9mUVv/eE4NJ5C4aTM0.uNdXpb/nfLbE/RkS/F2','renato2000@gmail.com','9233005487'),('777','joao','$2y$10$ObTFIvN7NYE4UP1odY1o0.JjKJAAuLtLvpqxxnWX76CMjTzmVDZNO','joao@gmail.com','55543125'),('987','Edson Filho','$2y$10$NMq0Glejhm5UkgvkgVJDG.WE4gr.rB8L3WxSzijk.WES7qogIB6bq','edson@filho.com','321654987');
/*!40000 ALTER TABLE `Usuarios` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-07-05 15:28:45
