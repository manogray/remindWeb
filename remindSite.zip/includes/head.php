<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="name" content="PsySchool">
<meta name="description" content="Sistema de Gerenciamento do CSPA - UFAM">
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.1.0/css/all.css" integrity="sha384-lKuwvrZot6UHsBSfcMvOkWwlCMgc0TaWr+30HWe3a4ltaBwTZhyTEggF5tJv8tbt" crossorigin="anonymous">
<link href="https://fonts.googleapis.com/css?family=Montserrat|Roboto:300" rel="stylesheet">
<link rel="stylesheet" href="../css/bootstrap.min.css">
<link rel="stylesheet" href="../css/main.css">
<link rel="stylesheet" type="text/css" href="../css/util.css">
<link rel="stylesheet" type="text/css" href="../css/login.css">
<link rel="stylesheet" type="text/css" href="../css/profile.css">
<link rel="stylesheet" href="../css/calendar.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.0/jquery.min.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
<script src="../js/fullcalendar.min.js"></script>
<script src="../js/validateCpf.js"></script>
<script src="../js/main.js"></script>
